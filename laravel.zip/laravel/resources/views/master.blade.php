<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
  <title>Omniware - Sample</title>
  <link rel="stylesheet" type="text/css" href="/css/style.css">
 </head>
 <body>
  	@yield('content')
  	@yield('alert')
 </body>
</html>
