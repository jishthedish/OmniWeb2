@extends ('master');

@section('content')
    
{{--
 Home Page

	<h1> {!! $name !!}</h1>

--}}
   

		<h2> {{ $lesson }} </h2>



@stop

