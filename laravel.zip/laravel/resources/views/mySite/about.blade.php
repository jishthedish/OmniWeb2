@extends ('master');

@section('content')
	About me 
@stop

@section('alert')
	<script>
	alert('About Page');
	</script>

@stop