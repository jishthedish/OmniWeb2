<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Contactslist extends Model {

	//
	 protected $table = 'contactslist';

}
