<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Mobilelist extends Model {

	//
	 protected $table = 'mobilelist';

}
